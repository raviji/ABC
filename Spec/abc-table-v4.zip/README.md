# ABC Table Component

## Installation

```bash
# install dependencies
npm i

# run application
# this will open http://localhost:4200
ng serve --open
```

## Commands

```bash
# run application in local
ng serve --open

# build application in development mode
ng build

# build application in production mode
ng build --prod

# run lint
ng lint

# run lint with fixing
ng lint --fix
```

## How to use it

To use this component from other application,\
Please make sure `@ng-bootstrap/ng-bootstrap` and `bootstrap` are installed.\
If not, run following command.

```bash
npm i @ng-bootstrap/ng-bootstrap bootstrap
``` 

Then edit `angular.json`.

```
"styles": [
  "src/styles.scss",
  + "node_modules/bootstrap/dist/css/bootstrap.min.css",
],
```

Next, copy and paste `src/app/abc-table` directory into your application.\
Last thing to do is import `AbcTableModule` from your module.

```typescript
@NgModule({
  import: [
    AbcTableModule,
  ],
})
```

## Available Components and Directives

### TableComponent

You can use table component with selector `<app-table>`.\
It has following attributes.

```angular2
// column definition for rendering header
columns: TableColumnData[] = [];
// data rows
rows: any[];
// loading state to show spinner
loading = false;
// set true will render leftmost column
// which contains action buttons
useControls = false;
// set true will render checkbox inside the leftmost column
// when checkbox checked, selectRowsChange event will be emitted with selected rows
selectable = false;
// set true will render edit button inside the leftmost column
// when button clicked, editClick event will be emitted with selected row
editable = false;
// set true will render delete button inside the leftmost column
// when button clicked, deleteClick event will be emitted with selected row
deletable = false;
// set true will render menu button inside the leftmost column
// when button clicked, menuClick event will be emitted with selected row
// if you want to render context menu, you need to set appTableContextMenu and appTableContextMenuContent
hasContextMenu = false;
// set true will render column fix controller
fixableColumns = false;
// set true will render column hide controller
hidableColumns = false;
// when using leftmost column with useControl=true,
// you can set order of inner controllers
actionOrder: OrderableAction[];
// leftmost column identifier name
// you can add style to leftmost column with [column-def-identifier='abc-table-controller']
controlColumnIdentifier = 'abc-table-controller';
// set page
// start from 0
page = 0;
// set size
size = 5;
// set total
// this is unnecessary when you will not use backend
total = 0;
// set headerFix attribute will fix the header
headerFix: any;
// set useBackend attribute will make table to work with backend
useBackend: any;
```

And followings are event that can be emitted from component.

```angular2
// emitted when page/size changed
// only work with useBackend attribute
pageValueChange: EventEmitter<PageValueChangeEvent>;
// emitted when column sorting changed
// only work with useBackend attribute
sortedColumnsChange: EventEmitter<SortedColumn[]>;
// emitted when selected rows changed by checkbox in leftmost column
// only work with useBackend attribute
selectRowsChange: EventEmitter<any[]>;
// emitted when filter changed
// only work with useBackend attribute
filterChange: EventEmitter<FilterChangeEvent>;
// emitted when delete button clicked
// current row data will be sent
deleteClick: EventEmitter<any>;
// emitted when edit button clicked
// current row data will be sent
editClick: EventEmitter<any>;
// emitted when menu button clicked
// current row data will be sent
menuClick: EventEmitter<any>;
```

### TableContextMenuDirective

This will be used for rendering outer of context menu.\
You can use this with `TableContextMenuContentDirective`.

### TableContextMenuContentDirective

This will be used for rendering inner of context menu.

## How to render context menu

```html
<app-table #tableComponent>
  <ng-container appTableContextMenu>
    <ng-template>
      <div appTableContextMenuContent>
        <div class="item" (click)="tableComponent.closeContextMenu()"></div>
        <div class="item" (click)="tableComponent.closeContextMenu()"></div>
        <div class="item" (click)="tableComponent.closeContextMenu()"></div>
        ...
      </div>
    </ng-template>
  </ng-container>
</app-table>
```

You have to follow above usage to render context menu inside the row.\
If you not set like that, context menu will not be rendered.\
The `appTableContextMenu` and `<ng-template>` are used for rendering `appTableContextMenuContent` to each row.\
As the `appTableContextMenuContent` is a real context menu, it automatically adds `abc-table-context-menu` class to its element.

For closing context menu when clicking menu items, you can use `closeContextMenu()` method in table component.\
This will allow you to close context menu from outside of the table component.\
By default, context menu can be closed when outside of itself clicked.

## How to set styles

Following styles must be called with `::ng-depp` from outside of the table component.

```scss
// set common cell style <th>/<td>
.abc-cell {}

// set header cell style
.abc-header-cell {}

// set body cell style
.abc-body-cell {}

// set <col> width
// when table is rendered, <colgroup> is automatically rendered with <col> tags
// each <col> tag has index number in 'column-def-index' attribute
// and each <col> tag has label name of header cell in 'column-def-identifier' attribute
// if label name for a header is 'Some Column', value of `column-def-identifier' will be 'some-column'
[column-def-index='0'] {}
[column-def-identifier='prop'] {}

// you can use app-table to set height of the component
// if you set app-table's height, table tag inside the component automatically adjusted
app-table {}
```
