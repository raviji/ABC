### TypeScript
```typescript
import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {TableColumnData} from '../../abc-table/table/table.component';

@Component({
  selector: 'app-fixable-column-table',
  templateUrl: './fixable-column-table.component.html',
  styleUrls: ['./fixable-column-table.component.scss']
})
export class FixableColumnTableComponent implements OnInit {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Column 1',
      property: 'column1',
    },
    {
      label: 'Column 2',
      property: 'column2',
    },
    {
      label: 'Column 3',
      property: 'column3',
    },
    {
      label: 'Column 4',
      property: 'column4',
    },
    {
      label: 'Column 5',
      property: 'column5',
    },
    {
      label: 'Column 6',
      property: 'column6',
    },
    {
      label: 'Column 7',
      property: 'column7',
    },
    {
      label: 'Column 8',
      property: 'column8',
    },
  ];
  
  rows: {
    column1: string;
    column2: string;
    column3: string;
    column4: string;
    column5: string;
    column6: string;
    column7: string;
    column8: string;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) {}

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loading = true;
    
    this.http.get('/assets/json/fixable-columns.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
```

### HTML

```html
<app-table
  [fixableColumns]="true"
  [columns]="columns"
  [rows]="rows"
  [loading]="loading"></app-table>
```

### SCSS

```scss
::ng-deep {
  col {
    width: 300px;
  }
}
```
