## Hidable columns demo

Set `true` for `hidableColumns` attribute can make columns hidable.

```html
<app-table
  [hidableColumns]="true"
  [columns]="columns"
  [rows]="rows"
  [loading]="loading"></app-table>
```

You can hide multiple columns with select element.
