### Delete button

Set `useControls: true` to use leftmost column.\
Then set `deletable: true` to use delete button from leftmost column.

Clicking delete button should emit `deleteClick` event with current row data.

### HTML
```html
<app-table
  [useControls]="true"
  [deletable]="true"
  [loading]="loading"
  [columns]="columns"
  [rows]="rows"
  (deleteClick)="deletableRow = $event"></app-table>

<div>
  {{deletableRow | json}}
</div>
```
