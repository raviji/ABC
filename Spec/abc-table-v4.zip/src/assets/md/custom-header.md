## Custom styled header demo

To add custom style to table header, please use `.abc-header-cell` class.

### SCSS

```scss
::ng-deep {
  .abc-header-cell {
    background-color: #cecece;
  }
}
```

