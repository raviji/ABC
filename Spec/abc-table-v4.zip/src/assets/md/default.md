## Default table demo

This is default table without any style, options.\
Only `columns`, `rows`, `loading` attributes are used.

When clicking header with `Ctrl` button pressed, you can toggle sorting.\
Then clicking sortable header with `Shift` button pressed will make change the sorting direction.

When using default table, pagination will be created with frontend data.\
If you want to use backend pagination data, see `Use with backend`.

### TypeScript

```typescript
import {Component, OnInit} from '@angular/core';
import {TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-default-table',
  templateUrl: './default-table.component.html',
  styleUrls: ['./default-table.component.scss']
})
export class DefaultTableComponent implements OnInit {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  timer: number;

  constructor(
    private http: HttpClient,
  ) {}

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loading = true;

    this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;

        // to show loading spinner
        setTimeout(() => {
          this.loading = false;
        }, 2000);
      });
  }
}
```

### HTML
```html
<app-table
  [loading]="loading"
  [columns]="columns"
  [rows]="rows"></app-table>
```

### SCSS
```scss
app-table {
  min-height: 300px;
}
```
