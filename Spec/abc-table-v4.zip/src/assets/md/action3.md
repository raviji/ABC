### Menu button

Set `useControls: true` to use leftmost column.\
Then set `hasContextMenu: true` to use menu button from leftmost column.

Clicking menu button should emit `menuClick` event with current row data.

To add context menu, please follow belows:

### TypeScript

```typescript
import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {TableColumnData, TableComponent} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-action-buttons-table',
  templateUrl: './action-buttons-table.component.html',
  styleUrls: ['./action-buttons-table.component.scss']
})
export class ActionButtonsTableComponent implements OnInit {
  @ViewChild('contextTable', {static: false}) private contextTable: TableComponent;

  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  editableRow = null;
  deletableRow = null;
  effectedRow = null;

  constructor(
    private http: HttpClient,
  ) { }

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loading = true;

    this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }

  onClick() {
    if (this.contextTable) {
      // closeContextMenu method can close context menu as its name
      this.contextTable.closeContextMenu();
    }
  }
}

```

### HTML
```html
<app-table
  #contextTable
  [useControls]="true"
  [hasContextMenu]="true"
  [loading]="loading"
  [columns]="columns"
  [rows]="rows"
  (menuClick)="effectedRow = $event">
  <!-- must use ng-container for appTableContextMenu -->
  <ng-container appTableContextMenu>
    <!-- wrap the appTableContextMenuContent with ng-template -->
    <ng-template>
      <div class="menu" appTableContextMenuContent>
        <div class="menu-item">
          Item 1
        </div>
        <div class="menu-item">
          Item 2
        </div>
        <div class="menu-item">
          Item 3
        </div>
        <div class="menu-item" (click)="onClick()">
          Close
        </div>
      </div>
    </ng-template>
  </ng-container>
</app-table>

<div>
  {{effectedRow | json}}
</div>
```

### SCSS
```scss
.menu {
  width: 150px;
  height: auto;
  border: 1px solid #cecece;

  .menu-item {
    box-sizing: border-box;
    padding: 0 10px;
    display: flex;
    align-items: center;
    height: 35px;
    cursor: pointer;

    &:hover {
      background-color: #fafafa;
    }
  }
}
```
