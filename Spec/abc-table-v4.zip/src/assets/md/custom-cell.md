## Custom styled cell demo

You can set style to cell of table body with `.abc-body-cell` class.

### SCSS
```scss
::ng-deep {
  .abc-body-cell {
    background-color: #cecece;
  }
}
```
