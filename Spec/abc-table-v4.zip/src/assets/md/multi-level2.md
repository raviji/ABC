For above table, `columns` are set as:

```typescript
columns: TableColumnData[] = [
  {
    label: 'ID',
    property: 'id',
  },
  {
    label: 'Status',
    property: null,
    children: [
      {
        label: 'Strength',
        property: 'status.str',
      },
      {
        label: 'Dexterity',
        property: 'status.dex',
      },
      {
        label: 'Intelligence',
        property: 'status.int',
      },
    ],
  },
];
```

And the data is:

```json
[
  {
    "id": "Great Warrior",
    "status": {
      "str": 80,
      "dex": 20,
      "int": 5
    }
  },
  {
    "id": "Mighty Magician",
    "status": {
      "str": 3,
      "dex": 6,
      "int": 120
    }
  },
  {
    "id": "Thief",
    "status": {
      "str": 30,
      "dex": 90,
      "int": 12
    }
  }
]
```

