## Multiple actions table demo

### TypeScript

```typescript
import {Component, OnInit} from '@angular/core';
import {TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-multiple-action-table',
  templateUrl: './multiple-action-table.component.html',
  styleUrls: ['./multiple-action-table.component.scss']
})
export class MultipleActionTableComponent implements OnInit {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loading = true;

    this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
```

### HTML

```html
<app-table
  #contextTable1
  [useControls]="true"
  [selectable]="true"
  [editable]="true"
  [deletable]="true"
  [hasContextMenu]="true"
  [loading]="loading"
  [columns]="columns"
  [rows]="rows">
  <ng-container appTableContextMenu>
    <ng-template>
      <div class="menu" appTableContextMenuContent>
        <div class="menu-item">
          Item 1
        </div>
        <div class="menu-item">
          Item 2
        </div>
        <div class="menu-item">
          Item 3
        </div>
        <div class="menu-item" (click)="contextTable1.closeContextMenu()">
          Close
        </div>
      </div>
    </ng-template>
  </ng-container>
</app-table>
```

### SCSS
```scss
.menu {
  width: 150px;
  height: auto;
  border: 1px solid #cecece;

  .menu-item {
    box-sizing: border-box;
    padding: 0 10px;
    display: flex;
    align-items: center;
    height: 35px;
    cursor: pointer;

    &:hover {
      background-color: #fafafa;
    }
  }
}
```
