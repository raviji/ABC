You can set order with `actionOrder` attribute when using multiple actions.

### TypeScript

```typescript
import {Component, OnDestroy, OnInit} from '@angular/core';
import {
  DELETE_ACTION, EDIT_ACTION,
  MENU_ACTION,
  OrderableAction,
  SELECT_ACTION,
  TableColumnData,
} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-multiple-action-table',
  templateUrl: './multiple-action-table.component.html',
  styleUrls: ['./multiple-action-table.component.scss']
})
export class MultipleActionTableComponent implements OnInit, OnDestroy {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  actionOrder: OrderableAction[] = [
    EDIT_ACTION,
    MENU_ACTION,
    DELETE_ACTION,
    SELECT_ACTION,
  ];

  constructor(
    private http: HttpClient,
  ) { }

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loading = true;

    this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
```


### HTML

```html
<app-table
  #contextTable2
  [useControls]="true"
  [selectable]="true"
  [editable]="true"
  [deletable]="true"
  [hasContextMenu]="true"
  [loading]="loading"
  [columns]="columns"
  [actionOrder]="actionOrder"
  [rows]="rows">
  <ng-container appTableContextMenu>
    <ng-template>
      <div class="menu" appTableContextMenuContent>
        <div class="menu-item">
          Item 1
        </div>
        <div class="menu-item">
          Item 2
        </div>
        <div class="menu-item">
          Item 3
        </div>
        <div class="menu-item" (click)="contextTable2.closeContextMenu()">
          Close
        </div>
      </div>
    </ng-template>
  </ng-container>
</app-table>
```
