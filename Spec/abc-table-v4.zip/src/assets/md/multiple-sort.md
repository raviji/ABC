## Multiple sort demo

This is demo table for multiple sort data.\
Since this demo use default table with only `columns`, `rows`, `loading` attributes,\
demo source code not be provided.

Just click headers with `Ctrl` and `Shift` pressed.
