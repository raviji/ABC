### SCSS

```scss
::ng-deep {
  [column-def-identifier='name'] {
    width: 40%;
  }

  [column-def-identifier='age'] {
    width: 20%;
  }

  [column-def-identifier='job'] {
    width: 40%;
  }
}
```

