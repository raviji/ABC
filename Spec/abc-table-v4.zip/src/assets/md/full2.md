### TypeScript

```typescript
import { Component, OnInit } from '@angular/core';
import {
  DELETE_ACTION,
  EDIT_ACTION,
  MENU_ACTION,
  SELECT_ACTION,
  OrderableAction,
  TableColumnData
} from '../../abc-table/table/table.component';

function randomNumber(min: number, max: number) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function randomString() {
  const strings = ['Jane', 'Jone', 'Smith', 'Wang', 'Medic', 'Scout', 'Amy', 'Jill', 'Travel'];

  return strings[randomNumber(0, strings.length)];
}

function randomDate() {
  const start = new Date(1990, 1, 1);
  const end = new Date();

  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function randomData() {
  const data = [];

  for (let i = 0; i < 100; i++) {
    data.push({
      'column-1': {
        'column-1-1': randomString(),
        'column-1-2': randomNumber(0, 9999),
      },
      'column-2': randomString(),
      'column-3': randomDate(),
      'column-4': {
        'column-4-1': (() => {
          const list = [];

          for (let j = 0; j < randomNumber(1, 5); j++) {
            list.push(randomString());
          }

          return list;
        })(),
        'column-4-2': randomString(),
      },
    });
  }

  return data;
}

type ToggleType = 'useControl' | 'selectable' | 'editable' | 'deletable' | 'useContextMenu';

@Component({
  selector: 'app-full-featured-table',
  templateUrl: './full-featured-table.component.html',
  styleUrls: ['./full-featured-table.component.scss']
})
export class FullFeaturedTableComponent implements OnInit {
  columns: TableColumnData[] = [
    {
      label: 'Column 1',
      property: 'column-1',
      children: [
        {
          label: 'Column 1-1',
          property: 'column-1.column-1-1',
        },
        {
          label: 'Column 1-2',
          property: 'column-1.column-1-2',
          filterable: true,
          dataType: 'number',
        },
      ]
    },
    {
      label: 'Column 2',
      property: 'column-2',
      filterable: true,
      dataType: 'string',
    },
    {
      label: 'Column 3',
      property: 'column-3',
      filterable: true,
      dataType: 'date',
    },
    {
      label: 'Column 4',
      property: 'column-4',
      children: [
        {
          label: 'Column 4-1',
          property: 'column-4.column-4-1',
        },
        {
          label: 'Column 4-2',
          property: 'column-4.column-4-2',
        },
      ],
    },
  ];

  rows: any[] = [];
  loading = false;
  useControl = false;
  selectable = false;
  editable = false;
  deletable = false;
  useContextMenu = false;
  actionOrder: OrderableAction[] = [];

  types: ToggleType[] = [
    'useControl',
    'selectable',
    'editable',
    'deletable',
    'useContextMenu',
  ];

  constructor() { }

  ngOnInit() {
    this.loading = true;
    this.rows = randomData();

    setTimeout(() => {
      this.loading = false;
    }, 1000);
  }

  toggleActions(type: ToggleType) {
    switch (type) {
      case 'useControl': {
        this.useControl = !this.useControl;
        break;
      }

      case 'selectable': {
        this.selectable = !this.selectable;
        this.toggleActionOrder(SELECT_ACTION);
        break;
      }

      case 'editable': {
        this.editable = !this.editable;
        this.toggleActionOrder(EDIT_ACTION);
        break;
      }

      case 'deletable': {
        this.deletable = !this.deletable;
        this.toggleActionOrder(DELETE_ACTION);
        break;
      }

      case 'useContextMenu': {
        this.useContextMenu = !this.useContextMenu;
        this.toggleActionOrder(MENU_ACTION);
        break;
      }
    }
  }

  getActionState(type: ToggleType) {
    switch (type) {
      case 'selectable': {
        return this.selectable;
      }

      case 'useControl': {
        return this.useControl;
      }

      case 'deletable': {
        return this.deletable;
      }

      case 'editable': {
        return this.editable;
      }

      case 'useContextMenu': {
        return this.useContextMenu;
      }
    }
  }

  toggleActionOrder(action: OrderableAction) {
    const index = this.actionOrder.indexOf(action);
    if (index !== -1) {
      this.actionOrder.splice(index, 1);
    } else {
      this.actionOrder.push(action);
    }
  }

  getJsonData() {
    return JSON.stringify(this.rows, null, 2);
  }
}
```

### HTML

```html
<div class="toggles" *ngIf="!loading">
  <div class="status">
    Action order: {{actionOrder | json}}
  </div>

  <div class="toggle" *ngFor="let type of types">
    <button (click)="toggleActions(type)">
      {{type}}
    </button>
    <span>{{getActionState(type)}}</span>
  </div>
</div>

<app-table
  #tableComponent
  headerFix
  [actionOrder]="actionOrder"
  [useControls]="useControl"
  [hasContextMenu]="useContextMenu"
  [selectable]="selectable"
  [editable]="editable"
  [deletable]="deletable"
  [hidableColumns]="true"
  [fixableColumns]="true"
  [columns]="columns"
  [rows]="rows"
  [loading]="loading"
  [size]="15">

  <ng-container appTableContextMenu>
    <ng-template>
      <div class="menu" appTableContextMenuContent>
        <div class="menu-item">Menu</div>
        <div class="menu-item">Menu</div>
        <div class="menu-item">Menu</div>
        <div class="menu-item">Menu</div>
        <div class="menu-item" (click)="tableComponent.closeContextMenu()">Close</div>
      </div>
    </ng-template>
  </ng-container>

</app-table>

<pre *ngIf="!loading"><code class="data"><b>Used Data:</b> {{getJsonData()}}</code></pre>
```

### SCSS

```scss
@mixin setColumnWidth($identifier) {
  [column-def-identifier='#{$identifier}'] {
    @content;
  }
}

:host {
  app-table {
    height: 500px;
  }

  ::ng-deep {
    .abc-cell {
      border-right: 1px solid #cecece;
      border-bottom: 1px solid #cecece;
    }

    .abc-header-cell {
      background-color: #efefef;
    }

    tbody {
      .abc-row:nth-child(2n) {
        .abc-cell {
          background-color: #f6f6f6;
        }
      }
    }

    @include setColumnWidth('abc-table-controller') {
      width: 120px;
    }

    @include setColumnWidth('column-1-1') {
      width: 120px;
    }

    @include setColumnWidth('column-1-2') {
      width: 250px;
    }

    @include setColumnWidth('column-2') {
      width: 400px;
    }

    @include setColumnWidth('column-3') {
      width: 600px;
    }

    @include setColumnWidth('column-4-1') {
      width: 400px;
    }

    @include setColumnWidth('column-4-2') {
      width: 400px;
    }
  }

  .menu {
    width: 150px;
    box-sizing: border-box;
    border: 1px solid #cecece;

    .menu-item {
      display: flex;
      align-items: center;
      height: 30px;
      padding: 0 10px;
      box-sizing: border-box;
      cursor: pointer;
      font-size: 14px;

      &:hover {
        background-color: #f6f6f6;
      }
    }
  }

  .toggles {
    display: flex;
    flex-direction: column;
    font-size: 14px;

    .status {
      margin-bottom: 10px;
    }

    .toggle {
      margin-bottom: 10px;
      display: flex;
      align-items: center;

      span {
        margin-left: 20px;
      }
    }
  }

  pre {
    .data {
      font-size: 12px;
    }
  }
}
```
