For above table, `<colgroup>` and `<col>` tags are rendered as following:

```html
<colgroup>
  <col column-def-index="0" column-def-identifier="name">
  <col column-def-index="1" column-def-identifier="age">
  <col column-def-index="2" column-def-identifier="job">
</colgroup>
```

So you can use `column-def-index` or `column-def-identifier` to set width of each column.\
**!Note** When you need to set specific width on some columns, all column should have own width to avoid unexpected UI break.
