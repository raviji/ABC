## Fixable columns demo

If you want to fix some columns from the left, use `fixableColumns` attribute of `<app-table>` component.\
Set `true` to `fixableColumns` attribute will render column fix controller on the top left of the table.
