## Action buttons demo

### Edit button

Set `useControls: true` to use leftmost column.\
Then set `editable: true` to use edit button from leftmost column.

Clicking edit button should emit `editClick` event with current row data.

### HTML
```html
<app-table
  [useControls]="true"
  [editable]="true"
  [loading]="loading"
  [columns]="columns"
  [rows]="rows"
  (editClick)="editableRow = $event"></app-table>

<div>
  {{editableRow | json}}
</div>
```
