For table with nested columns, `<colgroup>` and `<col>` will be rendered for columns which actual data.
So above table should render `<colgroup>` and `<col>` as following:

```html
<colgroup>
  <col column-def-index="0" column-def-identifier="id">
  <col column-def-index="1" column-def-identifier="strength">
  <col column-def-index="2" column-def-identifier="dexterity">
  <col column-def-index="3" column-def-identifier="intelligence">
</colgroup>
```
