## Use with backend demo

The table component support backend data fetching.\
It can send request to process paging, filtering, sorting.\
To work with backend, `useBackend` attribute must be set.

On page change, component emit `pageValueChange` event.\
On sort change, component emit `sortedColumnsChange` event.\
On filter change, component emit `filterChange` event.

**!Note** When using backend, `total`, `page`, `size` must be set.

### TypeScript

```typescript
import {Component, OnInit} from '@angular/core';
import {SortedColumn, TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';
import {PageValueChangeEvent} from '../../abc-table/table-paginator/table-paginator.component';
import {FilterChangeEvent} from '../../abc-table/table-filter/table-filter.component';

@Component({
  selector: 'app-backend-table',
  templateUrl: './backend-table.component.html',
  styleUrls: ['./backend-table.component.scss']
})
export class BackendTableComponent implements OnInit {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'A',
      property: 'A',
      filterable: true,
      dataType: 'string',
    },
    {
      label: 'B',
      property: 'B',
      filterable: true,
      dataType: 'number',
    },
    {
      label: 'C',
      property: 'C',
      filterable: true,
      dataType: 'date',
    },
  ];

  rows: {
    A: number;
    B: number;
    C: number;
  }[] = [];

  page = 0;
  size = 10;
  total = 0;
  sortedColumns: SortedColumn[] = [];
  changedFilter: FilterChangeEvent = null;

  constructor(
    private http: HttpClient,
  ) { }

  ngOnInit() {
    this.getData();
  }

  getData(page: number = this.page, size: number = this.size) {
    this.loading = true;

    this.http.get('/assets/json/backend.json')
      .subscribe((data: any[]) => {
        this.loading = false;

        /**
         * just mocking backend pagination
         * filtering and sorting not mocked from here
         */
        this.total = data.length;
        this.size = size;
        this.page = page;
        this.rows = data.splice(this.page * this.size, this.size);
      });
  }

  onPageValueChange(pageValue: PageValueChangeEvent) {
    this.getData(pageValue.page, pageValue.size);
  }
}
```

### HTML
```html
<app-table
  useBackend
  [columns]="columns"
  [rows]="rows"
  [loading]="loading"
  [total]="total"
  [page]="page"
  [size]="size"
  (pageValueChange)="onPageValueChange($event)"
  (sortedColumnsChange)="sortedColumns = $event"
  (filterChange)="changedFilter = $event"></app-table>

<div>
  {{sortedColumns | json}}
</div>

<div>
  {{changedFilter | json}}
</div>
```
