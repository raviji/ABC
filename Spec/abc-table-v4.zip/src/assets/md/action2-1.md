### Delete button with deleting row

This section demonstrate how to delete a row with `(deleteClick)` event.

### TypeScript

```typescript
import {Component, OnInit} from '@angular/core';
import {TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-action-buttons-table',
  templateUrl: './action-buttons-table.component.html',
  styleUrls: ['./action-buttons-table.component.scss']
})
export class ActionButtonsTableComponent implements OnInit {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  indexedRows: {
    id: number;
    name: string;
    age: number;
    job: string;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) { }

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loading = true;

    this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.indexedRows = this.rows.map((row, index) => {
          return {...row, id: index};
        });
        this.loading = false;
      });
  }

  deleteRow(row: any) {
    this.indexedRows = this.indexedRows.filter(r => r.id !== row.id);
  }
}
```

### HTML
```html
<app-table
  [useControls]="true"
  [deletable]="true"
  [loading]="loading"
  [columns]="columns"
  [rows]="indexedRows"
  (deleteClick)="deleteRow($event)"></app-table>
```
