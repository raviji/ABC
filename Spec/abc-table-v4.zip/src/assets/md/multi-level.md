## Multi level headers demo

The `TableColumnData` is interface for `columns` option item which has following properties:

```typescript
interface TableColumnData {
  label: string;
  property: string;
  filterable?: boolean;
  dataType?: FilterableDataType;
  children?: TableColumnData[];
}
```

If you want to render multi level headers, set `children` property.
