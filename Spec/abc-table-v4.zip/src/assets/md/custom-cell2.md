All the content in each cell wrapped with container which has `.abc-cell-inner` class.\
This container has default style as following:

### SCSS
```scss
.abc-cell-inner {
  padding: 5px 15px;
  display: flex;
}
```

So if you want to change cell inner padding, let's try following:

### SCSS
```scss
::ng-deep {
  .abc-cell-inner {
    padding: 20px;
  }
}
```

**!Note** When you change the `.abc-cell-inner` style, do not touch `display: flex`. Because that is used for displaying array value vertically.
