## Custom column width demo

When the table rendered, it renders `<colgroup>` too.\
Each `<col>` in the `<colgroup>` has unique attributes to make styling the column width to easy.
