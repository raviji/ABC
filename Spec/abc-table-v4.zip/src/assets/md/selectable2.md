
### TypeScript

```typescript
import {Component, OnInit} from '@angular/core';
import {TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-default-demo-table',
  templateUrl: './default-demo-table.component.html',
  styleUrls: ['./default-demo-table.component.scss']
})
export class DefaultDemoTableComponent implements OnInit {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  selectedRows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) { }

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loading = true;

    this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }

  onSelectRowsChange(
    rows: {
      name: string;
      age: number;
      job: string;
    }[]
  ) {
    this.selectedRows = rows;
  }
}

``` 

### HTML

```html
<app-table
  [useControls]="true"
  [selectable]="true"
  [columns]="columns"
  [rows]="rows"
  [loading]="loading"
  (selectRowsChange)="onSelectRowsChange($event)"></app-table>

<div>
  {{selectedRows | json}}
</div>
```
