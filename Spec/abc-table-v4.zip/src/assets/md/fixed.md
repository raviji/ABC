## Fixed header demo

You can fix header with `headerFix` attribute.

### HTML

```html
<app-table
  headerFix
  [columns]="columns"
  [rows]="rows"
  [size]="15"
  [loading]="loading"></app-table>
```

### SCSS

```scss
app-table {
  height: 500px;
}
```
