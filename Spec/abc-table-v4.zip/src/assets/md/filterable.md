## Filterable table demo

The `TableColumnData` is interface for `columns` option item which has following properties:

```typescript
interface TableColumnData {
  label: string;
  property: string;
  filterable?: boolean;
  dataType?: FilterableDataType;
  children?: TableColumnData[];
}
```

When you set `filterable` as `true`, you can use filter for specific column.\
In this case, `dataType` property must be set.

Available values for `dataType` is `'string' | 'number' | 'date'`.
