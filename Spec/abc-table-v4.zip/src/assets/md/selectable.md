## Selectable table demo

Set value of `useControl` and `selectable` attributes to `true`.\
The `useControls: true` will render leftmost column which has action controllers.\
And `selectable: true` will render checkboxes inside the leftmost column.

When checkbox toggled, `selectRowsChange` event emitted from table component.\
Its `$event` contains selected rows as array.
