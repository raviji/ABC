### TypeScript
```typescript
import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {TableColumnData} from '../../abc-table/table/table.component';

@Component({
  selector: 'app-filterable-table',
  templateUrl: './filterable-table.component.html',
  styleUrls: ['./filterable-table.component.scss']
})
export class FilterableTableComponent implements OnInit {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
      filterable: true,
      dataType: 'string',
    },
    {
      label: 'Grade',
      property: 'grade',
      filterable: true,
      dataType: 'number',
    },
    {
      label: 'Date of birth',
      property: 'dateOfBirth',
      filterable: true,
      dataType: 'date',
    },
  ];

  rows: {
    name: string;
    grade: number;
    dateOfBirth: string;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) {}

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loading = true;

    this.http.get('/assets/json/filterable.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      })
  }
}
```

### HTML
```html
<app-table
  [columns]="columns"
  [rows]="rows"
  [loading]="loading"></app-table>
```
