Using fixed column also possible.

### HTML

```html
<app-table
  headerFix
  [fixableColumns]="true"
  [columns]="columns"
  [rows]="rows"
  [size]="15"
  [loading]="loading"></app-table>
```

### SCSS

```scss

app-table {           
  height: 500px;

  ::ng-deep {
    // set cols size
    [column-def-identifier='a'] { width: 50px; }
    [column-def-identifier='b'] { width: 700px; }
    [column-def-identifier='c'] { width: 700px; }
  }
}
```
