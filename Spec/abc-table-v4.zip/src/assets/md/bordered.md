## Bordered table demo

To make table with border, you need to set style to `.abc-cell`.\
The `.abc-cell` is default class of the `<th>`, `<td>` tags.

You only need `border-right` and `border-bottom`.

### SCSS

```scss
::ng-deep {
  .abc-cell {
    border-right: 1px solid #cecece;
    border-bottom: 1px solid #cecece;
  }
}
```
