import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table-loading-spinner',
  template: '',
  styleUrls: ['./table-loading-spinner.component.scss']
})
export class TableLoadingSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
