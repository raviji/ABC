import { TableContextMenuDirective } from './table-context-menu.directive';

describe('TableContextMenuDirective', () => {
  it('should create an instance', () => {
    const directive = new TableContextMenuDirective();
    expect(directive).toBeTruthy();
  });
});
