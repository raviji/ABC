import { TableContextMenuContentDirective } from './table-context-menu-content.directive';

describe('TableContextMenuContentDirective', () => {
  it('should create an instance', () => {
    const directive = new TableContextMenuContentDirective();
    expect(directive).toBeTruthy();
  });
});
