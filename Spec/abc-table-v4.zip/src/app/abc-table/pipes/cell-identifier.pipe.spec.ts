import { CellIdentifierPipe } from './cell-identifier.pipe';

describe('CellIdentifierPipe', () => {
  it('create an instance', () => {
    const pipe = new CellIdentifierPipe();
    expect(pipe).toBeTruthy();
  });
});
