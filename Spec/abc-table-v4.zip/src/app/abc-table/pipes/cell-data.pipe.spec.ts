import { CellDataPipe } from './cell-data.pipe';

describe('CellDataPipe', () => {
  it('create an instance', () => {
    const pipe = new CellDataPipe();
    expect(pipe).toBeTruthy();
  });
});
