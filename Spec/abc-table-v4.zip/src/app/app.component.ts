import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  demoType = 'default';
  demoTypes = [
    'default',
    'multiple sort',
    'custom border',
    'custom header',
    'custom cell',
    'column width',
    'fixable column',
    'filterable table',
    'multi level headers',
    'selectable columns',
    'action buttons',
    'multiple actions',
    'use with backend',
    'fixed header',
    'hide/show columns',
    'full featured table',
  ];

  constructor() { }
}
