import {Subscription} from 'rxjs';

export class DemoCommonComponent {
  sub: Subscription;
  subs: Subscription[] = [];

  /**
   * unsubscribe all subscription
   */
  unsubscribeAll() {
    if (this.sub) {
      this.sub.unsubscribe();
    }

    (this.subs || []).forEach(sub => sub.unsubscribe());
  }
}
