import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-cell-table',
  templateUrl: './custom-cell-table.component.html',
  styleUrls: ['./custom-cell-table.component.scss']
})
export class CustomCellTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
