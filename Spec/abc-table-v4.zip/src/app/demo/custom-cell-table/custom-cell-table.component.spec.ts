import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomCellTableComponent } from './custom-cell-table.component';

describe('CustomCellTableComponent', () => {
  let component: CustomCellTableComponent;
  let fixture: ComponentFixture<CustomCellTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomCellTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomCellTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
