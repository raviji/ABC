import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiLevelTableComponent } from './multi-level-table.component';

describe('MultiLevelTableComponent', () => {
  let component: MultiLevelTableComponent;
  let fixture: ComponentFixture<MultiLevelTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiLevelTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiLevelTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
