import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multi-level-table',
  templateUrl: './multi-level-table.component.html',
  styleUrls: ['./multi-level-table.component.scss']
})
export class MultiLevelTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
