import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {
  DELETE_ACTION, EDIT_ACTION,
  MENU_ACTION,
  OrderableAction,
  SELECT_ACTION,
  TableColumnData,
  TableComponent
} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';
import {DemoCommonComponent} from '../common/demo-common.component';

@Component({
  selector: 'app-multiple-action-table',
  templateUrl: './multiple-action-table.component.html',
  styleUrls: ['./multiple-action-table.component.scss']
})
export class MultipleActionTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  actionOrder: OrderableAction[] = [
    EDIT_ACTION,
    MENU_ACTION,
    DELETE_ACTION,
    SELECT_ACTION,
  ];

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData() {
    this.loading = true;

    this.sub = this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
