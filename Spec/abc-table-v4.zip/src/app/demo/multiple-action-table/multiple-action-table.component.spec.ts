import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleActionTableComponent } from './multiple-action-table.component';

describe('MultipleActionTableComponent', () => {
  let component: MultipleActionTableComponent;
  let fixture: ComponentFixture<MultipleActionTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultipleActionTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
