import {Component, OnDestroy, OnInit} from '@angular/core';
import {TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';
import {DemoCommonComponent} from '../common/demo-common.component';

@Component({
  selector: 'app-default-table',
  templateUrl: './default-table.component.html',
  styleUrls: ['./default-table.component.scss']
})
export class DefaultTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  timer: number;

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();

    if (this.timer) {
      clearTimeout(this.timer);
    }
  }

  getData() {
    this.loading = true;

    this.unsubscribeAll();

    this.sub = this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;

        // to show loading spinner
        this.timer = setTimeout(() => {
          this.loading = false;
        }, 2000);
      });
  }
}
