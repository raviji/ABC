import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomHeaderTableComponent } from './custom-header-table.component';

describe('CustomHeaderTableComponent', () => {
  let component: CustomHeaderTableComponent;
  let fixture: ComponentFixture<CustomHeaderTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomHeaderTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomHeaderTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
