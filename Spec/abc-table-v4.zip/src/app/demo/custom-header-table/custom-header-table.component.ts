import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-header-table',
  templateUrl: './custom-header-table.component.html',
  styleUrls: ['./custom-header-table.component.scss']
})
export class CustomHeaderTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
