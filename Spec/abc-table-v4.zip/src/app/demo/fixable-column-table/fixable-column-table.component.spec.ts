import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FixableColumnTableComponent } from './fixable-column-table.component';

describe('FixableColumnTableComponent', () => {
  let component: FixableColumnTableComponent;
  let fixture: ComponentFixture<FixableColumnTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FixableColumnTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FixableColumnTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
