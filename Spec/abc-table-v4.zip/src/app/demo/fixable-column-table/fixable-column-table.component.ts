import {Component, OnDestroy, OnInit} from '@angular/core';
import {DemoCommonComponent} from '../common/demo-common.component';
import {HttpClient} from '@angular/common/http';
import {TableColumnData} from '../../abc-table/table/table.component';

@Component({
  selector: 'app-fixable-column-table',
  templateUrl: './fixable-column-table.component.html',
  styleUrls: ['./fixable-column-table.component.scss']
})
export class FixableColumnTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Column 1',
      property: 'column1',
    },
    {
      label: 'Column 2',
      property: 'column2',
    },
    {
      label: 'Column 3',
      property: 'column3',
    },
    {
      label: 'Column 4',
      property: 'column4',
    },
    {
      label: 'Column 5',
      property: 'column5',
    },
    {
      label: 'Column 6',
      property: 'column6',
    },
    {
      label: 'Column 7',
      property: 'column7',
    },
    {
      label: 'Column 8',
      property: 'column8',
    },
  ];

  rows: {
    column1: string;
    column2: string;
    column3: string;
    column4: string;
    column5: string;
    column6: string;
    column7: string;
    column8: string;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData() {
    this.loading = true;

    this.sub = this.http.get('/assets/json/fixable-columns.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
