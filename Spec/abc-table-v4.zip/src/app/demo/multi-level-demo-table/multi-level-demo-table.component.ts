import {Component, OnDestroy, OnInit} from '@angular/core';
import {TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';
import {DemoCommonComponent} from '../common/demo-common.component';

@Component({
  selector: 'app-multi-level-demo-table',
  templateUrl: './multi-level-demo-table.component.html',
  styleUrls: ['./multi-level-demo-table.component.scss']
})
export class MultiLevelDemoTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  columns: TableColumnData[] = [
    {
      label: 'ID',
      property: 'id',
    },
    {
      label: 'Status',
      property: null,
      children: [
        {
          label: 'Strength',
          property: 'status.str',
        },
        {
          label: 'Dexterity',
          property: 'status.dex',
        },
        {
          label: 'Intelligence',
          property: 'status.int',
        },
      ],
    },
  ];

  rows: {
    id: string;
    status: {
      str: number;
      dex: number;
      int: number;
    };
  }[] = [];

  loading = false;

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData() {
    this.loading = true;

    this.sub = this.http.get('/assets/json/multi-level.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
