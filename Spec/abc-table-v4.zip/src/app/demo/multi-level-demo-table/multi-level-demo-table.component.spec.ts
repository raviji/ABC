import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiLevelDemoTableComponent } from './multi-level-demo-table.component';

describe('MultiLevelDemoTableComponent', () => {
  let component: MultiLevelDemoTableComponent;
  let fixture: ComponentFixture<MultiLevelDemoTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiLevelDemoTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiLevelDemoTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
