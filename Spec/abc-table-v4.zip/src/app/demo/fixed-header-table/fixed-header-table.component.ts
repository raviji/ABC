import {Component, OnDestroy, OnInit} from '@angular/core';
import {DemoCommonComponent} from '../common/demo-common.component';
import {TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-fixed-header-table',
  templateUrl: './fixed-header-table.component.html',
  styleUrls: ['./fixed-header-table.component.scss']
})
export class FixedHeaderTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'A',
      property: 'A',
      filterable: true,
      dataType: 'string',
    },
    {
      label: 'B',
      property: 'B',
      filterable: true,
      dataType: 'number',
    },
    {
      label: 'C',
      property: 'C',
      filterable: true,
      dataType: 'date',
    },
  ];

  rows: {
    A: number;
    B: number;
    C: number;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData() {
    this.loading = true;

    this.sub = this.http.get('/assets/json/backend.json')
      .subscribe((data: any[]) => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
