import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FixedHeaderTableComponent } from './fixed-header-table.component';

describe('FixedHeaderTableComponent', () => {
  let component: FixedHeaderTableComponent;
  let fixture: ComponentFixture<FixedHeaderTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FixedHeaderTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FixedHeaderTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
