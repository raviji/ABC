import {Component, OnDestroy, OnInit} from '@angular/core';
import {SortedColumn, TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';
import {DemoCommonComponent} from '../common/demo-common.component';
import {PageValueChangeEvent} from '../../abc-table/table-paginator/table-paginator.component';
import {FilterChangeEvent} from '../../abc-table/table-filter/table-filter.component';

@Component({
  selector: 'app-backend-table',
  templateUrl: './backend-table.component.html',
  styleUrls: ['./backend-table.component.scss']
})
export class BackendTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'A',
      property: 'A',
      filterable: true,
      dataType: 'string',
    },
    {
      label: 'B',
      property: 'B',
      filterable: true,
      dataType: 'number',
    },
    {
      label: 'C',
      property: 'C',
      filterable: true,
      dataType: 'date',
    },
  ];

  rows: {
    A: number;
    B: number;
    C: number;
  }[] = [];

  page = 0;
  size = 10;
  total = 0;
  sortedColumns: SortedColumn[] = [];
  changedFilter: FilterChangeEvent = null;
  selectedRows: any[] = [];

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData(page: number = this.page, size: number = this.size) {
    this.loading = true;

    this.sub = this.http.get('/assets/json/backend.json')
      .subscribe((data: any[]) => {
        this.loading = false;

        this.total = data.length;
        this.size = size;
        this.page = page;
        this.rows = data.splice(this.page * this.size, this.size);
      });
  }

  onPageValueChange(pageValue: PageValueChangeEvent) {
    this.getData(pageValue.page, pageValue.size);
  }
}
