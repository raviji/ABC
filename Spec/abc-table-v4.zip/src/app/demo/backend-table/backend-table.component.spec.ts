import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BackendTableComponent } from './backend-table.component';

describe('BackendTableComponent', () => {
  let component: BackendTableComponent;
  let fixture: ComponentFixture<BackendTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BackendTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BackendTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
