import {Component, OnDestroy, OnInit} from '@angular/core';
import {DemoCommonComponent} from '../common/demo-common.component';
import {HttpClient} from '@angular/common/http';
import {TableColumnData} from '../../abc-table/table/table.component';

@Component({
  selector: 'app-filterable-table',
  templateUrl: './filterable-table.component.html',
  styleUrls: ['./filterable-table.component.scss']
})
export class FilterableTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
      filterable: true,
      dataType: 'string',
    },
    {
      label: 'Grade',
      property: 'grade',
      filterable: true,
      dataType: 'number',
    },
    {
      label: 'Date of birth',
      property: 'dateOfBirth',
      filterable: true,
      dataType: 'date',
    },
  ];

  rows: {
    name: string;
    grade: number;
    dateOfBirth: string;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData() {
    this.loading = true;

    this.sub = this.http.get('/assets/json/filterable.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
