import {Component, OnDestroy, OnInit} from '@angular/core';
import {DemoCommonComponent} from '../common/demo-common.component';
import {HttpClient} from '@angular/common/http';
import {TableColumnData} from '../../abc-table/table/table.component';

@Component({
  selector: 'app-multiple-sort-table',
  templateUrl: './multiple-sort-table.component.html',
  styleUrls: ['./multiple-sort-table.component.scss']
})
export class MultipleSortTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  columns: TableColumnData[] = [
    {
      label: 'Value 1',
      property: 'value1',
    },
    {
      label: 'Value 2',
      property: 'value2',
    },
    {
      label: 'Value 3',
      property: 'value3',
    },
  ];

  rows: {
    value1: number;
    value2: number;
    value3: number;
  }[] = [];

  loading = false;

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData() {
    this.loading = true;

    this.sub = this.http.get('/assets/json/multiple-sort.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
