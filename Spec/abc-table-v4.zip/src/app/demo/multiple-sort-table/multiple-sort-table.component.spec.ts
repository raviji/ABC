import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleSortTableComponent } from './multiple-sort-table.component';

describe('MultipleSortTableComponent', () => {
  let component: MultipleSortTableComponent;
  let fixture: ComponentFixture<MultipleSortTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultipleSortTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleSortTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
