import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-column-width-table',
  templateUrl: './column-width-table.component.html',
  styleUrls: ['./column-width-table.component.scss']
})
export class ColumnWidthTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
