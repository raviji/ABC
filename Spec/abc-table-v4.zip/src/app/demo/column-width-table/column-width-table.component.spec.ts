import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColumnWidthTableComponent } from './column-width-table.component';

describe('ColumnWidthTableComponent', () => {
  let component: ColumnWidthTableComponent;
  let fixture: ComponentFixture<ColumnWidthTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColumnWidthTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColumnWidthTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
