import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FullFeaturedTableComponent } from './full-featured-table.component';

describe('FullFeaturedTableComponent', () => {
  let component: FullFeaturedTableComponent;
  let fixture: ComponentFixture<FullFeaturedTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FullFeaturedTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FullFeaturedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
