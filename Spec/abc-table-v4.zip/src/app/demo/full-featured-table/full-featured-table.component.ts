import { Component, OnInit } from '@angular/core';
import {
  DELETE_ACTION,
  EDIT_ACTION,
  MENU_ACTION,
  OrderableAction,
  SELECT_ACTION,
  TableColumnData
} from '../../abc-table/table/table.component';

function randomNumber(min: number, max: number) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function randomString() {
  const strings = ['Jane', 'Jone', 'Smith', 'Wang', 'Medic', 'Scout', 'Amy', 'Jill', 'Travel'];

  return strings[randomNumber(0, strings.length)];
}

function randomDate() {
  const start = new Date(1990, 1, 1);
  const end = new Date();

  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function randomData() {
  const data = [];

  for (let i = 0; i < 100; i++) {
    data.push({
      'column-1': {
        'column-1-1': randomString(),
        'column-1-2': randomNumber(0, 9999),
      },
      'column-2': randomString(),
      'column-3': randomDate(),
      'column-4': {
        'column-4-1': (() => {
          const list = [];

          for (let j = 0; j < randomNumber(1, 5); j++) {
            list.push(randomString());
          }

          return list;
        })(),
        'column-4-2': randomString(),
      },
    });
  }

  return data;
}

type ToggleType = 'useControl' | 'selectable' | 'editable' | 'deletable' | 'useContextMenu';

@Component({
  selector: 'app-full-featured-table',
  templateUrl: './full-featured-table.component.html',
  styleUrls: ['./full-featured-table.component.scss']
})
export class FullFeaturedTableComponent implements OnInit {
  showCode = false;

  columns: TableColumnData[] = [
    {
      label: 'Column 1',
      property: 'column-1',
      children: [
        {
          label: 'Column 1-1',
          property: 'column-1.column-1-1',
        },
        {
          label: 'Column 1-2',
          property: 'column-1.column-1-2',
          filterable: true,
          dataType: 'number',
        },
      ]
    },
    {
      label: 'Column 2',
      property: 'column-2',
      filterable: true,
      dataType: 'string',
    },
    {
      label: 'Column 3',
      property: 'column-3',
      filterable: true,
      dataType: 'date',
    },
    {
      label: 'Column 4',
      property: 'column-4',
      children: [
        {
          label: 'Column 4-1',
          property: 'column-4.column-4-1',
        },
        {
          label: 'Column 4-2',
          property: 'column-4.column-4-2',
        },
      ],
    },
  ];

  rows: any[] = [];
  loading = false;
  useControl = false;
  selectable = false;
  editable = false;
  deletable = false;
  useContextMenu = false;
  actionOrder: OrderableAction[] = [];

  types: ToggleType[] = [
    'useControl',
    'selectable',
    'editable',
    'deletable',
    'useContextMenu',
  ];

  constructor() { }

  ngOnInit() {
    this.loading = true;
    this.rows = randomData();

    setTimeout(() => {
      this.loading = false;
    }, 1000);
  }

  toggleActions(type: ToggleType) {
    switch (type) {
      case 'useControl': {
        this.useControl = !this.useControl;
        break;
      }

      case 'selectable': {
        this.selectable = !this.selectable;
        this.toggleActionOrder(SELECT_ACTION);
        break;
      }

      case 'editable': {
        this.editable = !this.editable;
        this.toggleActionOrder(EDIT_ACTION);
        break;
      }

      case 'deletable': {
        this.deletable = !this.deletable;
        this.toggleActionOrder(DELETE_ACTION);
        break;
      }

      case 'useContextMenu': {
        this.useContextMenu = !this.useContextMenu;
        this.toggleActionOrder(MENU_ACTION);
        break;
      }
    }
  }

  getActionState(type: ToggleType) {
    switch (type) {
      case 'selectable': {
        return this.selectable;
      }

      case 'useControl': {
        return this.useControl;
      }

      case 'deletable': {
        return this.deletable;
      }

      case 'editable': {
        return this.editable;
      }

      case 'useContextMenu': {
        return this.useContextMenu;
      }
    }
  }

  toggleActionOrder(action: OrderableAction) {
    const index = this.actionOrder.indexOf(action);
    if (index !== -1) {
      this.actionOrder.splice(index, 1);
    } else {
      this.actionOrder.push(action);
    }
  }

  getJsonData() {
    return JSON.stringify(this.rows, null, 2);
  }

  toggleCode() {
    this.showCode = !this.showCode;
  }
}
