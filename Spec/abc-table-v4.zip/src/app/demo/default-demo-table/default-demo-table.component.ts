import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {TableColumnData} from '../../abc-table/table/table.component';
import {DemoCommonComponent} from '../common/demo-common.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-default-demo-table',
  templateUrl: './default-demo-table.component.html',
  styleUrls: ['./default-demo-table.component.scss']
})
export class DefaultDemoTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  @Input() useLazyLoading = false;
  @Input() useControl = false;
  @Input() selectable = false;

  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  timer: number;

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();

    if (this.timer) {
      clearTimeout(this.timer);
    }
  }

  getData() {
    this.loading = true;

    this.unsubscribeAll();

    this.sub = this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;

        if (this.useLazyLoading) {
          // to show loading spinner
          this.timer = setTimeout(() => {
            this.loading = false;
          }, 2000);
        } else {
          this.loading = false;
        }
      });
  }

  onSelectRowsChange(
    rows: {
      name: string;
      age: number;
      job: string;
    }[]
  ) {
    console.log(rows);
  }
}
