import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultDemoTableComponent } from './default-demo-table.component';

describe('DefaultDemoTableComponent', () => {
  let component: DefaultDemoTableComponent;
  let fixture: ComponentFixture<DefaultDemoTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefaultDemoTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultDemoTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
