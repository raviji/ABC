import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-bordered-table',
  templateUrl: './bordered-table.component.html',
  styleUrls: ['./bordered-table.component.scss']
})
export class BorderedTableComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }
}
