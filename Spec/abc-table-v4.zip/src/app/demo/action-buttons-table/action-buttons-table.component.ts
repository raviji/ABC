import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {TableColumnData, TableComponent} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';
import {DemoCommonComponent} from '../common/demo-common.component';

@Component({
  selector: 'app-action-buttons-table',
  templateUrl: './action-buttons-table.component.html',
  styleUrls: ['./action-buttons-table.component.scss']
})
export class ActionButtonsTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  @ViewChild('contextTable', {static: false}) private contextTable: TableComponent;

  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  indexedRows: {
    id: number;
    name: string;
    age: number;
    job: string;
  }[] = [];

  editableRow = null;
  deletableRow = null;
  effectedRow = null;

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData() {
    this.loading = true;

    this.sub = this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;
        this.indexedRows = this.rows.map((row, index) => {
          return {...row, id: index};
        });
        this.loading = false;
      });
  }

  onClick() {
    if (this.contextTable) {
      this.contextTable.closeContextMenu();
    }
  }

  deleteRow(row: any) {
    this.indexedRows = this.indexedRows.filter(r => r.id !== row.id);
  }
}
