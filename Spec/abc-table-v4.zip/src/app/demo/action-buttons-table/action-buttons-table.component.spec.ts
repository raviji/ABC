import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionButtonsTableComponent } from './action-buttons-table.component';

describe('ActionButtonsTableComponent', () => {
  let component: ActionButtonsTableComponent;
  let fixture: ComponentFixture<ActionButtonsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActionButtonsTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionButtonsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
