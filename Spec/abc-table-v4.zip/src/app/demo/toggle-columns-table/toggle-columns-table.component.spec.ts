import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToggleColumnsTableComponent } from './toggle-columns-table.component';

describe('ToggleColumnsTableComponent', () => {
  let component: ToggleColumnsTableComponent;
  let fixture: ComponentFixture<ToggleColumnsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToggleColumnsTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToggleColumnsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
