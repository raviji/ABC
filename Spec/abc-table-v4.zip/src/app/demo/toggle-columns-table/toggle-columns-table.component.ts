import {Component, OnDestroy, OnInit} from '@angular/core';
import {DemoCommonComponent} from '../common/demo-common.component';
import {TableColumnData} from '../../abc-table/table/table.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-toggle-columns-table',
  templateUrl: './toggle-columns-table.component.html',
  styleUrls: ['./toggle-columns-table.component.scss']
})
export class ToggleColumnsTableComponent extends DemoCommonComponent implements OnInit, OnDestroy {
  loading = false;
  columns: TableColumnData[] = [
    {
      label: 'Name',
      property: 'name',
    },
    {
      label: 'Age',
      property: 'age'
    },
    {
      label: 'Job',
      property: 'job'
    },
  ];

  rows: {
    name: string;
    age: number;
    job: string;
  }[] = [];

  constructor(
    private http: HttpClient,
  ) {
    super();
  }

  ngOnInit() {
    this.getData();
  }

  ngOnDestroy(): void {
    this.unsubscribeAll();
  }

  getData() {
    this.loading = true;

    this.sub = this.http.get('/assets/json/default.json')
      .subscribe(data => {
        this.rows = data as any;
        this.loading = false;
      });
  }
}
