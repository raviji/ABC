import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {AbcTableModule} from './abc-table/abc-table.module';
import {HttpClientModule} from '@angular/common/http';
import { DefaultTableComponent } from './demo/default-table/default-table.component';
import {MarkdownModule} from 'ngx-markdown';
import { MultipleSortTableComponent } from './demo/multiple-sort-table/multiple-sort-table.component';
import {FormsModule} from '@angular/forms';
import { BorderedTableComponent } from './demo/bordered-table/bordered-table.component';
import { DefaultDemoTableComponent } from './demo/default-demo-table/default-demo-table.component';
import { CustomHeaderTableComponent } from './demo/custom-header-table/custom-header-table.component';
import { CustomCellTableComponent } from './demo/custom-cell-table/custom-cell-table.component';
import { ColumnWidthTableComponent } from './demo/column-width-table/column-width-table.component';
import { FixableColumnTableComponent } from './demo/fixable-column-table/fixable-column-table.component';
import { MultiLevelTableComponent } from './demo/multi-level-table/multi-level-table.component';
import { MultiLevelDemoTableComponent } from './demo/multi-level-demo-table/multi-level-demo-table.component';
import { FilterableTableComponent } from './demo/filterable-table/filterable-table.component';
import { SelectableTableComponent } from './demo/selectable-table/selectable-table.component';
import { ActionButtonsTableComponent } from './demo/action-buttons-table/action-buttons-table.component';
import { MultipleActionTableComponent } from './demo/multiple-action-table/multiple-action-table.component';
import { BackendTableComponent } from './demo/backend-table/backend-table.component';
import { FixedHeaderTableComponent } from './demo/fixed-header-table/fixed-header-table.component';
import { ToggleColumnsTableComponent } from './demo/toggle-columns-table/toggle-columns-table.component';
import { FullFeaturedTableComponent } from './demo/full-featured-table/full-featured-table.component';

@NgModule({
  declarations: [
    AppComponent,
    DefaultTableComponent,
    MultipleSortTableComponent,
    BorderedTableComponent,
    DefaultDemoTableComponent,
    CustomHeaderTableComponent,
    CustomCellTableComponent,
    ColumnWidthTableComponent,
    FixableColumnTableComponent,
    MultiLevelTableComponent,
    MultiLevelDemoTableComponent,
    FilterableTableComponent,
    SelectableTableComponent,
    ActionButtonsTableComponent,
    MultipleActionTableComponent,
    BackendTableComponent,
    FixedHeaderTableComponent,
    ToggleColumnsTableComponent,
    FullFeaturedTableComponent
  ],
  imports: [
    BrowserModule,
    AbcTableModule,
    HttpClientModule,
    MarkdownModule.forRoot(),
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
